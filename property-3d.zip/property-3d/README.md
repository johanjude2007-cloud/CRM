# PARAPROP — 3D Property Control Deck

A single-file 3D visualization for managing a building's apartments: rent, dates,
utility bills and payment status, shown as a color-coded stack of floors you can
slice open.

## Run it

It must be served over HTTP — browsers block ES modules over `file://`, so
double-clicking `index.html` will show a blank page.

```bash
cd ~/Desktop/property-3d
python3 -m http.server 8000
```

Then open **http://localhost:8000** in your browser.

(Any static server works — `npx serve`, VS Code Live Server, etc.)

## How to use

1. **Set up** the building in the left rail — name, number of floors, apartments
   per floor, currency — then **Generate building**. (**Sample** fills every unit
   with example data.)
2. **Click a floor** (in the 3D view or the rail list) — it slides out like a
   drawer and the camera flies to it. Drag to orbit, scroll to zoom.
3. **Click a unit** to edit tenant name, monthly rent, next rent date, contract
   end date, electricity & water bills, and toggle which are paid. Colors update
   live and everything is saved to your browser (localStorage).

## Status colors

| Color | Meaning | Trigger |
|-------|---------|---------|
| 🟢 Healthy | All good | Rent + bills paid, contract not ending soon |
| 🟡 Attention | Needs a look | A bill unpaid, rent due ≤ 7 days, or contract ends ≤ 30 days |
| 🔴 Overdue | Action needed | Rent past its due date & unpaid, or contract already expired |
| ⚪ Vacant | No tenant | Unit has no tenant/rent filled in |

The rules live in the `unitStatus()` function in `index.html` — tweak the
thresholds there if you want different sensitivity.

## Notes

- **Offline / no CDN:** Three.js and its addons are vendored under `vendor/`, so
  the app needs no internet connection.
- **Data:** stored per-browser in `localStorage` under the key `paraprop:v1`.
  "Reset to sample building" clears it.
